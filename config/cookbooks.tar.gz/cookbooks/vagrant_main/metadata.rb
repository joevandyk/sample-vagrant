recipe "vagrant_main", "Installs base GG software"
depends "build-essential"
supports "ubuntu"
